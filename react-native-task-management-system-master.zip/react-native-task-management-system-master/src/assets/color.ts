export enum Color {
  SUN = '#CC7832',
  KIND = '#FFC66D',
  CARBON = '#1B1B1B',
  ASPHALT = '#2B2B2B',
  ENSIGN = '#3B3B3B',
  LIGHT = '#A9B7C6',
  NEAT = '#FFF',
  OCEAN = '#568BD8',
  FRANT ='#52D2FB',
  BLOOD = '#B00020'
}
