export enum Font {
  SNIGLET = 'Sniglet-Regular',
  SNIGLET_EXTRA_BOLD = 'Sniglet-ExtraBold'
}
