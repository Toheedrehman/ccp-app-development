export interface IdentifiableModel {
  id: number;
}
