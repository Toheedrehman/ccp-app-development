export interface TimeLoggableModel {
  timeLogged: string;
}
