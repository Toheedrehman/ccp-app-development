export interface Lookup {
  id: number;
  name: string;
}
