export interface ProjectLimitedModel {
  projectId: number;
}
