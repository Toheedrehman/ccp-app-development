export interface TimeStamp {
  hours: number;
  minutes: number;
  seconds: number;
}
