export interface TaskTimeline {
  taskid: number;
  taskname: string;
  userid: number;
  username: string;
  datecreated: string;
  timecreated: string;
  status: string;
}
