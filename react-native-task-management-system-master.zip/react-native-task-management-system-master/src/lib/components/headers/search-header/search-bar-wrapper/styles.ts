import { StyleSheet } from "react-native";

export default StyleSheet.create({
  searchBar: {
    height: '100%',
    elevation: 0
  }
})
