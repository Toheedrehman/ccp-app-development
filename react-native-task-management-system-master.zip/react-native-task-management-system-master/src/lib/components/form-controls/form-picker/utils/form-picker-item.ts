export interface FormPickerItem {
  label: string;
  value: number;
}
