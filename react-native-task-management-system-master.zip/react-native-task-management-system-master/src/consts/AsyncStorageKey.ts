export enum AsyncStorageKey {
  JWT_TOKEN = 'JWT_TOKEN'
}
