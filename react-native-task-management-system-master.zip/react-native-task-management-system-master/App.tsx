import AppAuthSwitchNavigator from './src/navigation/AppAuthSwitchNavigator';

export default AppAuthSwitchNavigator
