## Authorize
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/login.png" alt="drawing" width="400"/>

## View tasks
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/taskList.png" alt="drawing" width="400"/>

## Add new ones
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/addTask.png" alt="drawing" width="400"/>

## View task details
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/taskDetails.png" alt="drawing" width="400"/>

## Log time
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/taskLog.png" alt="drawing" width="400"/>

## Change status
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/taskStatus.png" alt="drawing" width="400"/>

## Look up throw status flow
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/taskFlow.png" alt="drawing" width="400"/>

## View users
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/userList.png" alt="drawing" width="400"/>

## Add new ones
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/newUser.png" alt="drawing" width="400"/>

## Navigate throw screens
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/sideBar.png" alt="drawing" width="400"/>

## View teams
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/teamList.png" alt="drawing" width="400"/>

## Add new ones
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/addTeam.png" alt="drawing" width="400"/>

## View profile
<img src="https://raw.githubusercontent.com/EugeneOwl/react-native-task-management-system/master/src/assets/images/readme/userProfile.png" alt="drawing" width="400"/>
